package com.example.fev16;

import android.app.Application;
import android.content.Context;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class App extends Application {
    static List<Carro>stand = new ArrayList<>();
    public  static Context ctx;
    public  static  final String  TAG="Xpto";
    @Override
    public void onCreate() {
        super.onCreate();
        ctx=getApplicationContext();
        Log.i(TAG,"App Create");
        CarregarLista();
        for(Carro c : stand){
            Log.i(TAG,c.toString());
        }
    }

    static  public void CarregarLista(){
        Mysql mysql = new Mysql(ctx,1);
        stand = mysql.carregaLista();
    }
//    static public void criarLista(){
//        stand.add(new Carro(1,"Ford","Luxo", new byte[]{}));
//        stand.add(new Carro(2,"Ferrari","Desportivo", new byte[]{}));
//        stand.add(new Carro(3,"BMW","Luxo", new byte[]{}));
//        stand.add(new Carro(4,"Volkswagen","Utilitário", new byte[]{}));
//    }
}
