package com.example.fev16;

import static com.example.fev16.MainActivity.CANALFOTO;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.IOException;

public class Insert extends AppCompatActivity {

    Button btinsert, btc;
    EditText editid, editmodelo;

    ImageView imgfoto;
    Spinner spincat;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==CANALFOTO1){
            Uri uri = Uri.parse(data.getData().toString());
            try {
                Bitmap bmp = MediaStore.Images.Media.getBitmap(getContentResolver(),uri);
                imgfoto.setImageBitmap(bmp);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        }
    }

    public  static  final int CANALFOTO1=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);
        editmodelo = findViewById(R.id.edit_modelo_insert);
        editid=findViewById(R.id.edit_id_insert);
        btc = findViewById(R.id.bt_cancel_insert);
        btc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btinsert =findViewById(R.id.bt_insert_insert);
        btinsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Mysql mysql = new Mysql(Insert.this,1);
                int id = Integer.parseInt( editid.getText().toString());
                String modelo = editmodelo.getText().toString();
                String categoria = spincat.getSelectedItem().toString();
                BitmapDrawable drw = (BitmapDrawable) imgfoto.getDrawable();
                Bitmap bmp = drw.getBitmap();
                Carro novo = new Carro(id,modelo,categoria,bmp);
                mysql.inserirCarro(novo);
                App.stand = mysql.carregaLista();
                finish();
            }
        });


        spincat =findViewById(R.id.spin_categoria_insert);
         ArrayAdapter<String>adpt = new ArrayAdapter<>(
                 Insert.this,
                 androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,
                 getResources().getStringArray(R.array.categorias)
         );
         adpt.setDropDownViewResource(androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
         spincat.setAdapter(adpt);
         spincat.setSelection(0);

         imgfoto = findViewById(R.id.img_foto_insert);
         imgfoto.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 Intent itfoto = new Intent(Intent.ACTION_GET_CONTENT);
                 itfoto.setType("image/*");
                 startActivityForResult(itfoto,CANALFOTO1);
             }
         });

    }
}