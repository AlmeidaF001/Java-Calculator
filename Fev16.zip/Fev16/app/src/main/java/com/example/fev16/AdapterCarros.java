package com.example.fev16;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdapterCarros extends RecyclerView.Adapter<AdapterCarros.ViewHolder> {

    public Context ctx;
    public List<Carro> carros;

    public AdapterCarros(Context ctx, List<Carro> carros) {
        this.ctx = ctx;
        this.carros = carros;
    }

    @NonNull
    @Override
    public AdapterCarros.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(ctx).inflate(R.layout.itemcarro, parent, false);
        return new ViewHolder(v);
    }

    ISacaFoto listener;

    public void setOnSacaFotoListener(ISacaFoto lst) {
        listener = lst;
    }

    private IOnDeleteListener listenerdelete;

    public void OnsetDeleteListener(IOnDeleteListener lst) {
        listenerdelete = lst;
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterCarros.ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Carro carro = carros.get(position);
        holder.btdelete.setTag(carro);
        holder.btdelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Carro carro = (Carro) holder.btdelete.getTag();
                Mysql mysql = new Mysql(ctx, 1);
                long deletedRows = mysql.deleteCarro(carro.getIdcar());
                if (deletedRows > 0) {
                    Toast.makeText(v.getContext(), "Carro eliminado", Toast.LENGTH_LONG).show();
                    App.CarregarLista();
                    listenerdelete.OnDeleteHandler();
                } else {
                    Toast.makeText(v.getContext(), "Falha ao eliminar o carro", Toast.LENGTH_LONG).show();
                }
            }
        });

        holder.editid.setText(String.valueOf(carro.getIdcar()));
        holder.editmodelo.setText(carro.getModelo());
        ArrayAdapter<String> adpt = new ArrayAdapter<>(
                ctx,
                androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,
                ctx.getResources().getStringArray(R.array.categorias)
        );
        adpt.setDropDownViewResource(androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        holder.spincat.setAdapter(adpt);
        int pos = adpt.getPosition(carro.getCategoria());
        holder.spincat.setSelection(pos);

        if (carro.getFoto().length > 0) {
            holder.imgfoto.setImageBitmap(Carro.ArrayToBitmap(carro.getFoto()));
        }
        holder.imgfoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.OnSacaFoto(position);
            }
        });

        holder.btupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Carro carro = carros.get(position);
                Mysql mysql = new Mysql(ctx, 1);
                long updatedRows = mysql.updateCarro(carro);
                if (updatedRows > 0) {
                    Toast.makeText(v.getContext(), "Carro atualizado", Toast.LENGTH_LONG).show();
                    App.CarregarLista();
                    notifyDataSetChanged(); // Notifica o adapter sobre a mudança
                } else {
                    Toast.makeText(v.getContext(), "Falha ao atualizar o carro", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return carros.size();
    }

    //inner class ViewHolder
    public class ViewHolder extends RecyclerView.ViewHolder {
        EditText editid, editmodelo;
        Spinner spincat;
        ImageView imgfoto;
        Button btdelete, btupdate;

        public ViewHolder(@NonNull View v) {
            super(v);
            editid = v.findViewById(R.id.edit_id_itemcarro);
            editmodelo = v.findViewById(R.id.edit_modelo_itemcarro);
            spincat = v.findViewById(R.id.spin_categoria_itemcarro);
            imgfoto = v.findViewById(R.id.img_foto_itemcarro);
            btdelete = v.findViewById(R.id.bt_delete_itemcarro);
            btupdate = v.findViewById(R.id.bt_update_itemcarro);
        }
    }
}
