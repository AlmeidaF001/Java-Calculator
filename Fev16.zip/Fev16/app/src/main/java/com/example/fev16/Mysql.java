package com.example.fev16;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class Mysql extends SQLiteOpenHelper {
    public static final String DATABASENAME = "stand.db";
    public static final String TABLENAME = "Carros";
    public static final String IDCAR = "idcar";
    public static final String MODELO = "modelo";
    public static final String CATEGORIA = "categoria";
    public static final String FOTO = "foto";

    Context ctx;

    public Mysql(@Nullable Context context,
                 int version) {
        super(context, "stand.db", null, version);
        ctx = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE " + TABLENAME + " ( " +
                "    " + IDCAR + "     INT  PRIMARY KEY, " +
                "    " + MODELO + "    TEXT, " +
                "    " + CATEGORIA + " TEXT, " +
                "    " + FOTO + "      BLOB " +
                "); ";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String sql = "Drop table  if exists " + TABLENAME + ";";
        db.execSQL(sql);
        onCreate(db);
    }

    public static final String TAG = "Xpto";

    long inserirCarro(Carro novo) {
        long total = 0;
        SQLiteDatabase db = getWritableDatabase();
        try {
            db.beginTransaction();
            ContentValues cv = new ContentValues();
            cv.put(IDCAR, novo.getIdcar());
            cv.put(MODELO, novo.getModelo());
            cv.put(CATEGORIA, novo.getCategoria());
            cv.put(FOTO, novo.getFoto());
            total = db.insert(TABLENAME, null, cv);
            db.setTransactionSuccessful();

        } catch (SQLException erro) {
            Log.i(TAG, erro.getMessage().toString());

        }

        db.endTransaction();
        db.close();
        return total;
    }

    public List<Carro> carregaLista() {
        List<Carro> lista = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from Carros;";
        Cursor cur = db.rawQuery(sql, null);
        if (cur.getCount() > 0) {
            cur.moveToFirst();
            do {
                Carro novo = new Carro(cur.getInt(0), cur.getString(1), cur.getString(2), cur.getBlob(3));
                lista.add(novo);
            } while (cur.moveToNext());
        }
        return lista;
    }

    ;

    public long deleteCarro(int id) {
        long total = 0;
        SQLiteDatabase db = getWritableDatabase();
        try {
            db.beginTransaction();
            total = db.delete(TABLENAME, IDCAR + "=?", new String[]{String.valueOf(id)});
            db.setTransactionSuccessful();
        } catch (SQLException erro) {
            Toast.makeText(ctx, erro.getMessage(), Toast.LENGTH_SHORT).show();
        }
        db.endTransaction();
        return total;
    }
    public long updateCarro(Carro novo) {
        long total = 0;
        SQLiteDatabase db = getWritableDatabase();
        try {
            db.beginTransaction();
            ContentValues cv = new ContentValues();
            cv.put(IDCAR, novo.getIdcar());
            cv.put(MODELO, novo.getModelo());
            cv.put(CATEGORIA, novo.getCategoria());
            cv.put(FOTO, novo.getFoto());
            // Verifique se a consulta está correta e os parâmetros estão sendo passados corretamente
            total = db.update(TABLENAME, cv, IDCAR + "=?", new String[]{String.valueOf(novo.getIdcar())});
            db.setTransactionSuccessful();
        } catch (SQLException erro) {
            Toast.makeText(ctx, erro.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            db.endTransaction();
        }
        return total;
    }


}
