package com.example.fev16;

public interface ISacaFoto {
    void OnSacaFoto(int posicao);
}
