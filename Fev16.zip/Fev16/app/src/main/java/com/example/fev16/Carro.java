package com.example.fev16;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.io.ByteArrayOutputStream;

public class Carro implements Parcelable {
    @NonNull
    @Override
    public String toString() {
        return String.format("%d %s %s",idcar,modelo,categoria);
    }

    // region Campos
   private int idcar;
   private  String modelo;

   private String categoria;

   private  byte[] foto;
   // endregion

    //region Getters & Setters

    protected Carro(Parcel in) {
        idcar = in.readInt();
        modelo = in.readString();
        categoria = in.readString();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            foto = in.readBlob();
        }
    }

    public static final Creator<Carro> CREATOR = new Creator<Carro>() {
        @Override
        public Carro createFromParcel(Parcel in) {
            return new Carro(in);
        }

        @Override
        public Carro[] newArray(int size) {
            return new Carro[size];
        }
    };

    public int getIdcar() {
        return idcar;
    }

    public void setIdcar(int idcar) {
        this.idcar = idcar;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public byte[] getFoto() {
        return foto;
    }

    public void setFoto(byte[] foto) {
        this.foto = foto;
    }


    //endregion


    public Carro(int idcar, String modelo, String categoria, byte[] foto) {
        this.idcar = idcar;
        this.modelo = modelo;
        this.categoria = categoria;
        this.foto = foto;
    }
    public Carro(int idcar, String modelo, String categoria,Bitmap bmp) {
        this.idcar = idcar;
        this.modelo = modelo;
        this.categoria = categoria;
        this.foto = BitmapToArray(bmp);
    }

    public static byte[]   BitmapToArray(Bitmap bmp){
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG,100,stream);
        return stream.toByteArray();
    }

    public  static Bitmap ArrayToBitmap(byte[] foto){
        return BitmapFactory.decodeByteArray(foto,0, foto.length);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeInt(idcar);
        dest.writeString(modelo);
        dest.writeString(categoria);
        dest.writeBlob(foto);
    }
}
