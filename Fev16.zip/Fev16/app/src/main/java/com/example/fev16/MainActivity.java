package com.example.fev16;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private static final int CANALINSERT = 2;
    AdapterCarros adptcarros;
    RecyclerView recycle_carros;
    Button button_voltar;

    FloatingActionButton fabinsert;
    int Posicao=0;
    public  static  final int CANALFOTO=1;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==CANALFOTO){
            Uri uri = Uri.parse(data.getData().toString());
            try {
                Bitmap bmp = MediaStore.Images.Media.getBitmap(getContentResolver(),uri);
                App.stand.get(Posicao).setFoto(Carro.BitmapToArray(bmp));
                adptcarros.notifyDataSetChanged();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }


        }
        if(requestCode==CANALINSERT){
            finish();
            overridePendingTransition(0,0);
            startActivity(getIntent());
            overridePendingTransition(0,0);

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fabinsert = findViewById(R.id.floatingActionButton);
        fabinsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Insert", Toast.LENGTH_SHORT).show();
                Intent itinsert = new Intent(MainActivity.this, Insert.class);
                startActivityForResult(itinsert, CANALINSERT);
            }
        });
        recycle_carros=findViewById(R.id.recycle_carros_main);
        adptcarros = new AdapterCarros(MainActivity.this,App.stand);
        adptcarros.OnsetDeleteListener(new IOnDeleteListener() {
            @Override
            public void OnDeleteHandler() {
                finish();
                overridePendingTransition(0,0);
                startActivity(getIntent());
                overridePendingTransition(0,0);
            }
        });


        adptcarros.setOnSacaFotoListener(new ISacaFoto() {
            @Override
            public void OnSacaFoto(int posicao) {
                Posicao=posicao;
                Intent itfoto= new Intent(Intent.ACTION_GET_CONTENT);
                itfoto.setType("image/*");
                startActivityForResult(itfoto,CANALFOTO);
            }
        });


        recycle_carros.setAdapter(adptcarros);
        recycle_carros.setLayoutManager(new LinearLayoutManager(this));

        // Button to launch the other app
        button_voltar = findViewById(R.id.button_voltar);
        button_voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClassName("com.example.pratica", "com.example.pratica.MainActivity");
                startActivity(intent);
            }
        });
    }
}
