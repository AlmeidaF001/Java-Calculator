package com.example.fev16;

public interface IOnUpdateListener {
    void OnUpgradeHandler();
}
