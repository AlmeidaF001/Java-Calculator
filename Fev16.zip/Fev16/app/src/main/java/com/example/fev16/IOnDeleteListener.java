package com.example.fev16;

public interface IOnDeleteListener {
    void OnDeleteHandler();
}
